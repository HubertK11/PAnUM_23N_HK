package com.example.lab01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private TextView resultValue;
    private Spinner conversionType;
    private Button convertButton;

    private static final String[] CONVERSIONS = {
            "Złotówki na Euro",
            "Centymetry na Cal",
            "Stopnie Celsjusza na Fahrenheita",
            "Kilometry na Mile",
    };

    private static final double[] CONVERSION_FACTORS = {
            0.22,
            0.393701,
            0,
            0.621371,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.edycjaTekstu);
        resultValue = findViewById(R.id.textView);
        conversionType = findViewById(R.id.spinner);
        convertButton = findViewById(R.id.button);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.lista, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conversionType.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String input = inputValue.getText().toString();

        if (input.isEmpty()) {
            Toast.makeText(this, "Wpisz wartość do konwersji", Toast.LENGTH_SHORT).show();
            return;
        }

        double value = Double.parseDouble(input);
        String selectedConversion = conversionType.getSelectedItem().toString();
        double result = 0;

        for (int i = 0; i < CONVERSIONS.length; i++) {
            if (selectedConversion.equals(CONVERSIONS[i])) {
                if (selectedConversion.equals("Stopnie Celsjusza na Fahrenheita")) {
                    result = (value * 9 / 5) + 32;
                } else if (selectedConversion.equals("Fahrenheita na Stopnie Celsjusza")) {
                    result = (value - 32) * 5 / 9;
                } else {
                    result = value * CONVERSION_FACTORS[i];
                }
                break;
            }
        }

        resultValue.setText(String.format("Wynik: %.2f", result));
    }
}