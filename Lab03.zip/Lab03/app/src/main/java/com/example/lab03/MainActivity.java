package com.example.lab03;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private int seconds = 0;
    private int hundredths = 0;
    private boolean running = false;

    private int minutesTimer = 0;
    private int secondsTimer = 0;
    private int tenthsTimer = 0;
    private boolean isRunningTimer = false;
    private boolean isStartedTimer = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        runTimer();
        runCountdownTimer();
    }

    public void onClickStart(View view) {
        running = true;
    }

    public void onClickStop(View view) {
        running = false;
    }

    public void onClickReset(View view) {
        running = false;
        seconds = 0;
        hundredths = 0;
    }

    private void runTimer() {
        final TextView timeView = findViewById(R.id.stoper);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds / 3600;
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;
                String time = String.format(Locale.US, "%d:%02d:%02d.%d", hours, minutes, secs, hundredths);
                timeView.setText(time);
                if (running) {
                    if (++hundredths == 10) {
                        seconds++;
                        hundredths = 0;
                    }
                }
                handler.postDelayed(this, 100);
            }
        });
    }

    public void onClickStartTimer(View view) {
        if (!isStartedTimer) {
            EditText minutesText = findViewById(R.id.minutes);
            EditText secondsText = findViewById(R.id.secends);
            try {
                minutesTimer = Integer.parseInt(minutesText.getText().toString());
            } catch (NumberFormatException e) {
                minutesTimer = 0;
            }
            try {
                secondsTimer = Integer.parseInt(secondsText.getText().toString());
            } catch (NumberFormatException e) {
                secondsTimer = 0;
            }
        }
        isStartedTimer = true;
        isRunningTimer = true;
    }

    public void onClickStopTimer(View view) {
        isRunningTimer = false;
    }

    public void onClickResetTimer(View view) {
        isRunningTimer = false;
        isStartedTimer = false;
        tenthsTimer = 0;
        secondsTimer = 0;
        minutesTimer = 0;
        TextView textView = findViewById(R.id.Timer);
        textView.setText(R.string.minutnikVal);
    }

    private void runCountdownTimer() {
        final TextView textView = findViewById(R.id.Timer);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (isRunningTimer) {
                    if (--tenthsTimer < 0) {
                        tenthsTimer = 9;
                        if (--secondsTimer < 0) {
                            secondsTimer = 59;
                            if (--minutesTimer < 0) {
                                isRunningTimer = false;
                                minutesTimer = 0;
                                secondsTimer = 0;
                                tenthsTimer = 0;
                            }
                        }
                    }
                    String time = String.format(Locale.US, "%02d:%02d", minutesTimer, secondsTimer);
                    textView.setText(time);
                }
                handler.postDelayed(this, 100);
            }
        });
    }
}