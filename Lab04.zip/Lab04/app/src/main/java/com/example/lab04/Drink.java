package com.example.lab04;

public class Drink {
    private String name;
    private String description;
    private String price;
    private int imageResourceId;
    public static final Drink[] drinks = {
            new Drink("Latte", "Mała czarna kawa z mlekiem i pianą.", "8 zł.", R.drawable.latte),
            new Drink("Cappuccino", "Mała czarna z dużą ilością mleka.", "11 zł.", R.drawable.cappuccino),
            new Drink("Espresso", "Czarna kawa z mielonych ziaren.","7,-", R.drawable.filter)
    };

    private Drink(String name, String description, String price, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResourceId = imageResourceId;
    }

    public String getDescription() {return description;}

    public void setName(String name) {this.name = name;}

    public String getName() {return name;}

    public String getPrice() {return price;}

    @Override
    public String toString() {return name; }

    public int getImageResourceId() {return imageResourceId;
    }
}
