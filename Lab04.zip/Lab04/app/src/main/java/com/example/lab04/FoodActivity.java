package com.example.lab04;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FoodActivity extends AppCompatActivity {

    public static final String EXTRA_FOODID = "foodId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_food);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int foodId = (Integer)getIntent().getExtras().get(EXTRA_FOODID);
        Food food = Food.foods[foodId];
        TextView name = (TextView)findViewById(R.id.name);
        name.setText(food.getName());
        TextView description = (TextView)findViewById(R.id.description);
        description.setText(food.getDescription());
        TextView price = (TextView)findViewById(R.id.price);
        price.setText(food.getPrice());
        ImageView photo2 = (ImageView)findViewById(R.id.photo2);
        photo2.setImageResource(food.getImageResourceId());
        photo2.setContentDescription(food.getName());
    }
}