package com.example.lab04;

public class Food {
    private String name;
    private String description;
    private String price;
    private int imageResourceId;
    public static final Food[] foods = {
            new Food("Donut", "Okrągły pączek z polewą czekoladową.", "6 zł.", R.drawable.donut),
            new Food("Croissant", "Rogalik świeżo pieczony.", "4 zł.", R.drawable.croissant),
            new Food("Cupcakes", "Babeczki zwane muffinkami.", "1 zł.", R.drawable.cupcakes)
    };
    private Food(String name, String description, String price, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResourceId = imageResourceId;
    }
    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {return price;}

    @Override
    public String toString() {
        return name; }

    public int getImageResourceId() {
        return imageResourceId;
    }
}